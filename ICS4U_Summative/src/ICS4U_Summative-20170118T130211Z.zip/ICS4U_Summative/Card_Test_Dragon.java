
public class Card_Test_Dragon extends Minion{

	public Card_Test_Dragon() {
		super("        Test Dragon",1, 12, 12, 0,0, "Battlecry: Deal 5 Damage               ",0,0);
	}
}