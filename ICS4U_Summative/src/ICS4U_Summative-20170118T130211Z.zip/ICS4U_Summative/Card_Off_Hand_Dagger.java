
public class Card_Off_Hand_Dagger extends Gear{
	public Card_Off_Hand_Dagger(){
		super("Off-Hand Dagger", 0, 2, 0,0,-1, 2,"",0);
	}
}
