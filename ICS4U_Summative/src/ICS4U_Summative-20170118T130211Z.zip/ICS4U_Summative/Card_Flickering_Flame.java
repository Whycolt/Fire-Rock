
public class Card_Flickering_Flame extends Spell{
	public Card_Flickering_Flame(){
		super("    Flickering Flame",0,0,0, 6, "Deal 2 damage. Draw a card.", 2);
		
	}
}
