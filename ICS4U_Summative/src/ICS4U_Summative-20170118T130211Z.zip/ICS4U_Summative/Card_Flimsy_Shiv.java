
public class Card_Flimsy_Shiv extends Gear{
	public Card_Flimsy_Shiv(){
		super("Flimsy Shiv", 0, 1, 0,0,-1, 1,"",0);
	}
}
