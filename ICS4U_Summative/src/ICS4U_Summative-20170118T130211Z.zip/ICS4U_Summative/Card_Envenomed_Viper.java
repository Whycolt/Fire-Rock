
public class Card_Envenomed_Viper extends Minion{
	public Card_Envenomed_Viper(){
		super("     Envenomed Viper", 0, 1, 1, 2, -1, "If this minion damages another minion, destroy that minion",0,0);
	}

}
