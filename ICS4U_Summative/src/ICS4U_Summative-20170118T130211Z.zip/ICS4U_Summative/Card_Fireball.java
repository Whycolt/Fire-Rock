
public class Card_Fireball extends Spell{
	
	public Card_Fireball(){
		super("    Fireball",2,0,1,1,"Deal 6 damage.",6);
	}
	

}
