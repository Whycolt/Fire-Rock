
public class Card_Backstreet_Alchemist extends Minion{

	public Card_Backstreet_Alchemist(){
		super("    Backstreet Alchemist", 2,5,5,1,5,"Restore 10 hp to a hero", 0, -10);
	}
}
