
public class Card_Lay_On_Hands extends Spell{
	public Card_Lay_On_Hands(){
		super("       Lay On Hands", 2, 0, 0, 6, "Restore 8 hp. Draw 4 cards",8);
	}
}
