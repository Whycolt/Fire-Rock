import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.event.*;
import javax.swing.*;

public class Frame extends JFrame{
//Constructor
	public Frame(){
		super("FIRE ROCK");
		Container c = getContentPane();
		Game g = new Game(c);
		this.setSize(1314, 740);
	}//end Frame
}//end class Main