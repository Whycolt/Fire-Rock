
public class Card_Chillwind_Yeti extends Minion{
	
	public Card_Chillwind_Yeti(){
		super("        Chillwind Yeti", 1, 4, 5, -1, -1,"",0,0);
	}

}
