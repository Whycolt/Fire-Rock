
public class Card_Lord_Of_Winds extends Minion{
	public Card_Lord_Of_Winds(){
		super("     Lord of Winds",2,7,3,5,-1,"Charge",0,0);
	}
}
