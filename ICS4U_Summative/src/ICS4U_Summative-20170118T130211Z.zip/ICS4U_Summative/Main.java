/**
 * name: Colt Ma 
 * teacher: Mrs.Strelkovska
 * course: ICS4U
 * date: Oct 31, 2016
 * Assignment: ArrayList Exercise
 * Description: Use array lists to read words from a file and print how many times it shows up + sort. 
 */
import java.awt.event.*;
import javax.swing.*;

public class Main {
//Main Method
	public static void main(String[] args){
		Frame app = new Frame();
		app.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		app.show();
	}//end main Method
}//end class Main
