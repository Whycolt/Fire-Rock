
public class Card_Paladin_Lord extends Minion{
	public Card_Paladin_Lord(){
		super("    Paladin Lord",2,5,5,4,-1,"Add a 5 atk AshBringer to your hand",0,0);
	}

}
