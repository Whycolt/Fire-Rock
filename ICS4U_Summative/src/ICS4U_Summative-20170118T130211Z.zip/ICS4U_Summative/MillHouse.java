
public class MillHouse extends Bot{
	public MillHouse(){
		super("Mill", 1, 50);
		super.addcard(new Enemy_Card_Test_Cow(),30);
	}

}
