
public class Card_Blessed_Longsword extends Gear{
	public Card_Blessed_Longsword(){
		super("Blessed Longsword", 2, 4, 0,0,9, 1,"Restore 5 hp to a hero                              ",-5);
	}
}
