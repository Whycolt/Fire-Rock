
public class Card_Boulderfist_Ogre extends Minion{
		
		public Card_Boulderfist_Ogre(){
			super("        Boulderfist Ogre", 2, 6, 7, -1, -1,"",0,0);
		}

}
