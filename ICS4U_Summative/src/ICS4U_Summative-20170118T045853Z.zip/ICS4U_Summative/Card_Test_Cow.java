
public class Card_Test_Cow extends Minion{

		public Card_Test_Cow() {
			super("             COW",1, 3, 3, -1,-1, "Battlecry: Give a Minion +5/+5               ",0,5);
		}
}
