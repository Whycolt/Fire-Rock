
public class Card_Reno_Jackson extends Minion{
	public Card_Reno_Jackson(){
		super("    Reno Jackson",2,4,6,1,5,"Fully heal a Hero",0,-30);
	}
}
