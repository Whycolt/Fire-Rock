import java.util.ArrayList;
import java.util.Collections;

public class Bot extends Hero{

	private String name;
	private int side;
	
	public Bot(String name, int side) {
		super(name, side);
		
	}

	
	public void play(Board b){
		ArrayList<Card> hand=b.getEnemyHand();
		int action = b.getEnemyAction();
		ArrayList cost=new ArrayList();
		if (hand.size()>0){
			Card highest = hand.get(0);	//hand.indexOf(Collections.max(cost)));
			if (highest instanceof Minion){
				b.play((Minion)highest, null);
			}
			if (highest instanceof Spell)
				b.play((Spell)highest, null);
			if (highest instanceof Gear)
				b.play((Gear)highest, null);
		}
		
	}
	
	
}
