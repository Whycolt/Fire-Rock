import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.LayoutManager;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import javax.imageio.ImageIO;
import javax.swing.*;
import javafx.scene.text.*;

public class Board extends JPanel implements ActionListener{
//variables
	private static final String[] settingList = {"board_default"};
	private static BufferedImage boardImage;
	private Card targeter,card,endTurn,boardB;
	public Hero player;
	public Bot enemy;
	public Gear[] playerGear = new Gear[3];
	public Gear[] enemyGear = new Gear[3];
	public int[] attacked;
	public ArrayList<Minion> enemyMinion = new ArrayList<Minion>();
	public ArrayList<Minion> playerMinion = new ArrayList<Minion>();
	private ArrayList<Card> playerDeck = new ArrayList<Card>();
	private ArrayList<Card> playerHand = new ArrayList<Card>();
	private ArrayList<Card> enemyDeck = new ArrayList<Card>();
	private ArrayList<Card> enemyHand = new ArrayList<Card>();
	private int playerAction,enemyAction, targetE,targetP,rng;
	private boolean targeting;
	private int turnEnd;//0 in neutral player turn, 1 in neutral enemy turn, 2 when enemy ends, wrap to 0
	public static final String filePath = new File("").getAbsolutePath() + "/src/";
	public static Font smalletter;
	private HomeButton x;
	private boolean neutralState = false;
	
//Constructor
 	public Board(int currentSetting){
 		smalletter = new Font("Default",Font.PLAIN,9);
		this.setLayout(null);
		this.setSize(1366, 768);
		x = new HomeButton(this);
 		add(x);
 		x.setBounds( 0, 0,50, 25);
		attacked = new int[7];
		playerAction = 2;
		player = new Hero("whycolt",0);
		enemy = new Bot("Meamatho",1);
		player.addActionListener(this);
		enemy.addActionListener(this);
		this.add(player);
		this.add(enemy);
		targeting = false;
		endTurn = new EndButton();
		//750->y,
		endTurn.setBounds(1166,330,100,50);
		endTurn.addActionListener(this);
		this.add(endTurn);
		boardB = new BoardDirt();
		boardB.setBounds(250, 200, 917, 301);
		boardB.addActionListener(this);
		this.add(boardB);
		for (int i=0; i<20; i++){
			enemyDeck.add(new Enemy_Card_Test_Cow());
		}
	}//end Board
//Vital Methods
	//paint
 	public void startGame(){
		for (int i=0;i<5;i++){
			cDraw(player);
			cDraw(enemy);
		}
 	}
	public void paintComponent(Graphics g){
		super.paintComponent(g);
		this.draw(g);
		if (targeting){
			targeter.draw(g);
		}
		g.setColor(Color.GREEN);
		if (playerAction == 2)
			g.fillRect(753, 500, 414, 100);
		else if(playerAction == 1)
			g.fillRect(753, 500, 207, 100);
		if (enemyAction == 2)
			g.fillRect(753, 100, 414, 100);
		else if(enemyAction == 1)
			g.fillRect(753, 100, 207, 100);
		g.setColor(Color.BLACK);
		g.drawRect(753, 501, 414, 99);
		g.drawRect(753, 501, 207, 99);
		g.drawRect(753, 101, 414, 99);
		g.drawRect(753, 101, 207, 99);
		
		enemy.setBounds(653,100,100,100);
		player.setBounds(653,500,100,100);
		int s = enemyMinion.size();
		for (int i = 0; i < s; i++){  
			enemyMinion.get(i).setBounds(50+120*i ,80,96,100);
		}//end draw enemy minions
		s = playerMinion.size();
		for (int i = 0; i < s; i++){
			playerMinion.get(i).setBounds(50+120*i ,180,96,100);
		}//end draw player minion
		s = enemyHand.size();
		for (int i = 0; i < s; i++){  
			enemyHand.get(i).setBounds(125+115*i ,90,96,137);
		}//end draw enemy minions
		s = playerHand.size();
		for (int i = 0; i < s; i++){
			playerHand.get(i).setBounds(125+115*i ,610,96,137);
		}//end draw player minion
	}//end paintComponent
	//Drawing the board
	public void draw(Graphics g){
		//g.drawImage(boardImage, 0, 0, this.getWidth(), this.getHeight(), null);
	}//end draw
	
	public void setDeck(ArrayList<Card> a){
		playerDeck=a;
	}
	
//Interactive Methods
	
	//turn started
	public void turnStart(Hero hero){
		neutralState=true;
		cDraw(hero);
		System.out.println(" draw "+hero.name);
		if (hero==player){
			for (int i=0; i<playerHand.size(); i++)
				System.out.println(playerHand.get(i).name);
			playerAction = 2;
			turnEnd = 0;
			player.reset();
			if (playerMinion.size()>0)
				for (int i = 0; i < playerMinion.size(); i++)
					playerMinion.get(i).reset();
		}
		else if(hero==enemy){
			enemyAction=2;
			turnEnd = 1;
			enemy.reset();
			if (enemyMinion.size()>0)
				for (int i = 0; i < enemyMinion.size(); i++)
					enemyMinion.get(i).reset();
		}
		repaint();
		enemy.play(this);
	}//end turnStart
	
	public void cDraw(Hero h){
		if(h.getSide() == 0){
			if (playerDeck.size()>0){
				rng = (int)(Math.random()*playerDeck.size());
				if (playerHand.size() < 10){
					playerHand.add(playerDeck.get(rng));
					this.add(playerDeck.get(rng));
					playerDeck.get(rng).addActionListener(this);
				}
				playerDeck.remove(rng);	
			}
		}
		else{
			if (enemyDeck.size()>0){
				rng = (int)(Math.random()*enemyDeck.size());
				if (enemyHand.size() < 10){
					enemyHand.add(enemyDeck.get(rng));
					this.add(enemyDeck.get(rng));
					enemyDeck.get(rng).addActionListener(this);
				}
				enemyDeck.remove(rng);
			}	
		}
	}
	//turn end
	public void turnEnd(Hero hero){
		neutralState=false;
		if (hero==player)
			turnEnd = 1;
		else if (hero==enemy)
			turnEnd = 2;
		System.out.println(hero.name + "Turn ending");
	}//end turnEnd
	
	//Start Target ->Need revision
	public void targetStart(Card c){
		targeter = c;
		targetP = c.getTarget();
		targetE = c.getEffect();
		targeting = true;
	}//end targetStart
	
	//Check target/exit
	public boolean targetCheck(Card c){
		//0-> All
		//System.out.println("Printing Target");
		if(targetP == 0)
			return true;
		//1-> All Enemies
		else if (targetP == 1 && c.getSide() == 1)
			return true;
		//2-> All Enemy Minions
		else if (targetP == 2 && c.getSide() == 1 && c instanceof Minion)
			return true;
		//3-> All Friendlies
		else if (targetP == 3 && c.getSide() == 0)
			return true;
		//4-> All Friendly Minions
		else if (targetP == 2 && c.getSide() == 0 && c instanceof Minion)
			return true;
		//5-> Heroes
		else if (targetP==5 && c instanceof Hero){
			return true;
		}
		else
			return false;
	}//end targetCheck
	//Summoning minion
	//Playing minion from hand
	public void play(Minion c,Card t){
		if (c.getSide() == 0){
			if (turnEnd==0){
				System.out.println("on player side" + c.getCost() +"  "+playerAction);
				if (playerMinion.size() < 7){
					if (c.getCost() <= playerAction){
						System.out.println("added to list");
						playerAction -= c.getCost();
						c.summon(this,t);
						playerMinion.add(c);
						playerHand.remove(c);
						boardB.add(c);
					}
				}
			}
			else
				System.out.println("Not your turn");
		}
		else{
			if (enemyMinion.size() < 7){
				if (c.getCost() <= enemyAction){ 
					enemyAction -= c.getCost();
					c.summon(this,t);
					enemyMinion.add(c);
					enemyHand.remove(c);
					this.remove(c);
					boardB.add(c);
				}
			}
		}
	}//end play
	//Playing spells from hand
	public void play(Spell c,Card t){
		if (c.getSide() == 0){
			if (c.getCost() <= playerAction){
				playerAction -= c.getCost();
				c.play(this,t);
				playerHand.remove(c);
			}
		}
		else{
			if (c.getCost() <= enemyAction){
				enemyAction -= c.getCost();
				c.play(this,t);
				enemyHand.remove(c);
			}
		}
	}//end play
	public void play(Gear c,Card t){
		if (c.getSide() == 0){
			if (c.getCost() <= playerAction){
				playerAction -= c.getCost();
				if (playerGear[c.getSlot()]!=null)
					playerGear[c.getSlot()].remove(player);
				playerGear[c.getSlot()] = c;
				c.equip(player,this,t);
				c.removeActionListener(this);
				playerHand.remove(c);
			}
		}
		else{
			if (c.getCost() <= enemyAction){
				enemyAction -= c.getCost();
				if (enemyGear[c.getSlot()]!=null)
					enemyGear[c.getSlot()].remove(enemy);
				enemyGear[c.getSlot()] = c;
				c.equip(enemy,this,t);
				c.removeActionListener(this);
				enemyHand.remove(c);
			}
		}
	}//end play
	//Removing card from board
	public void destroy(Minion c){
		if (c.getSide() == 0){
			playerMinion.remove(c);
			boardB.remove(c);
		}
		else{
			enemyMinion.remove(c);
			boardB.remove(c);
		}
	}//end remove
//getter and setter
	//check end turn
	public int getEnd(){
		return(turnEnd);
	}//end getEnd
	public boolean over(){
		return !(player.getHp() <= 0 || enemy.getHp() <= 0);
	}
	public ArrayList getEnemyHand(){
		return enemyHand;
	}
	public int getEnemyAction(){
		return enemyAction;
	}
	public void setEnemyAction(int x){
		enemyAction=x;
	}
	public boolean getState(){
		return neutralState;
	}
	
//vital
	public void actionPerformed(ActionEvent e) {
		if(turnEnd!=2){
		card = (Card)e.getSource();
		if (card == endTurn){
			if (turnEnd==0)
				turnEnd(player);
			else if (turnEnd==1)
				turnEnd(enemy);
			//else if (turnEnd==2)
				//turnEnd=0;
		}
		else if (!targeting){
			if(card != endTurn && card != boardB && ((Card) card).getSide() == 0){
				System.out.println("targeting" + card.getTarget());
				targetStart(card);
			}
			else if (card != endTurn && card != boardB && ((Card) card).getSide() == 1){
				System.out.println("targeting" + card.getTarget());
				targetStart(card);
				targetP = 10;
			}
			else{
				System.out.println("Invalid target" + playerHand.size()+"."+playerDeck.size());
			}
		}
		else{
			if (card == targeter){
				targeting = false;
				System.out.println("cancelled");
			}
			else if(targeter.getTarget() == -1 &&card == boardB&& (targeter instanceof Spell || (targeter instanceof Minion && ((Minion) targeter).getForm() == 0) || targeter instanceof Gear)){
				if (targeter instanceof Minion)
					play((Minion)targeter,null);
				else if (targeter instanceof Spell)
					play((Spell)targeter,null);
				else if (targeter instanceof Gear){
					play((Gear)targeter,null);
					targeter.move(0,0);
				}
				targeting = false;
			}
			else if (targeter instanceof Hero){
				if (targetCheck((Card)card)){
					if (card instanceof Minion)
						((Hero) targeter).battle(this, (Minion)card);
					else if (card instanceof Hero)
						((Hero)targeter).smorc(this, (Hero)card);
					targeting = false;
				}
				//invalid target
			}
			else if (targeter instanceof Minion && ((Minion)targeter).getForm() == 1 && card != endTurn && card != boardB){
				if (targetCheck((Card)card)){
					//System.out.println(card.getSide());
					//System.out.println(targeter.getTarget());
					if (card instanceof Minion && ((Minion)card).getForm() == 1)
						((Minion) targeter).battle(this, (Minion)card);
					else if (card instanceof Hero)
						((Minion)targeter).smorc(this, (Hero)card);
					targeting = false;
				}
			}
			else if (targeter instanceof Minion && ((Minion)targeter).getForm() == 0 && card != endTurn && card != boardB){
				if (targetCheck((Card)card)){
					if (card instanceof Minion && ((Minion)card).getForm() == 1)
						play((Minion)targeter,(Card)card);
					else if (card instanceof Hero)
						play((Minion)targeter, (Hero)card);
					targeting = false;
				}
			}
			else if (targeter instanceof Gear && card != endTurn && card != boardB){
				if (targetCheck((Card)card)){
					if (card instanceof Minion  && ((Minion)card).getForm() == 1)
						play((Gear)targeter,(Card)card);
					else if (card instanceof Hero)
						play((Gear)targeter,(Hero)card);
					targeting = false;
				}
			}
			else if (targeter instanceof Spell && card instanceof Card&& card != endTurn && card != boardB){
				if (targetCheck((Card)card)){
					if (card instanceof Minion  && ((Minion)card).getForm() == 1)
						play((Spell)targeter,(Card)card);
					else if (card instanceof Hero)
						play((Spell)targeter,(Hero)card);
					targeting = false;
				}
			}
			else{
				System.out.println("Invalid target");
				//invalid target
			}
		}
		repaint();
		}
		if (turnEnd==2){
			turnEnd=0;
		}
	}
	
	public void effect(Card c, Card t){
		Board b = this;
		switch(c.getEffect()){
		case 0: //buffing
			if (t instanceof Minion){
				Minion w = (Minion) t;
				w.setHp(0, c.getValue());
				w.setAtk(0, c.getValue());
			}
			break;
		case 1: //damage/healing
			if (t instanceof Minion){
				Minion w = (Minion) t;
				w.setHp(0, -c.getValue());
				w.checkIsDead(b, w);
				t = w;
			}
			else if (t instanceof Hero){
				Hero w = (Hero) t;
				w.setHp(b, -c.getValue());
				t = w;
			}
			repaint();
			break;
		case 2: //venomous
			break;
		case 3: //I BRING LIFE AND HOPE
			Hero w = (Hero) t;
			t.setHp(b, 60);
			break;
		case 4: //PUT YOUR FAITH IN THE LIGHT DUN DUN DUNDUNDUN
			Card AshBringer = new Card_AshBringer();
			playerHand.add(AshBringer);
			this.add(AshBringer);
			AshBringer.addActionListener(this);
			break;
		case 5: //Charge
			Minion k = (Minion)c;
			k.setAttack(true);
			c = k;
			break;
		case 6: //damage + draw
			if (t instanceof Minion){
				Minion l = (Minion) t;
				l.setHp(0, -c.getValue());
				l.checkIsDead(b, l);
				t = l;
			}
			else if (t instanceof Hero){
				Hero l = (Hero) t;
				l.setHp(b, -c.getValue());
				t = l;
			}
			for (int i=0; i<c.getValue()/2;i++){
				if (c.getSide()==0)
					cDraw(player);
				else
					cDraw(enemy);
			}
			break;
		case 7: //Card advantage
			for (int i=0; i<c.getValue();i++){
				if (c.getSide()==0)
					cDraw(player);
				else
					cDraw(enemy);
			}
			break;
		case 8: //Polymorph
			if (t instanceof Minion){
				Minion m = (Minion) t;
				destroy(m);
				Minion Sheep = new Card_Sheep();
				enemyHand.add(Sheep);
				this.add(Sheep);
				Sheep.addActionListener(this);
				b.play(Sheep, null);
				break;
			}
			
			
		}
		
	}
}//end class Board