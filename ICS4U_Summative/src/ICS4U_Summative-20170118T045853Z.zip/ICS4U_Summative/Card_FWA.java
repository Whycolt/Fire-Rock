
public class Card_FWA extends Gear{

	public Card_FWA(){
		super("Fiery War Axe", 1, 3, 0,0,-1, 1,"",0);
	}
}
