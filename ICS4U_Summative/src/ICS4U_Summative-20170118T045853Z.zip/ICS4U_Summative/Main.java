import java.awt.event.*;
import javax.swing.*;

public class Main {
//Main Method
	public static void main(String[] args){
		Frame app = new Frame();
		app.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		app.show();
	}//end main Method
}//end class Main
