
public class Card_Flamewreathed_Faceless extends Minion{
	public Card_Flamewreathed_Faceless(){
		super("   Flamewreathed Faceless", 4, 7,7,-1,-1,"",0,0);
	}
}
