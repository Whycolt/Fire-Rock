
public class Card_Unleashed_Kraken extends Minion{
	public Card_Unleashed_Kraken(){
		super("    Unleashed Kraken",2,6,6,1,0,"Deal 6 Damage",0,6);
	}
}
