
public class Card_Party_Deeps extends Minion{
	public Card_Party_Deeps(){
		super("    Party DeePS", 1, 6,2,-1,-1,"",0,0);
	}

}
