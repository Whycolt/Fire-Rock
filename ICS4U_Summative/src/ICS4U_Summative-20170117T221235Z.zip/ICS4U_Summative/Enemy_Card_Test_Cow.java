
public class Enemy_Card_Test_Cow extends Minion{

		public Enemy_Card_Test_Cow() {
			super("        EVIL COW",1, 3, 3, -1,-1, "Battlecry: Give a Minion +5/+5               ",1);
		}
}
