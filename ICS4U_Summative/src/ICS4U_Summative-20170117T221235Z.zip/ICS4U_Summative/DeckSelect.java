import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JPanel;

public class DeckSelect extends JPanel implements ActionListener{

	private JButton play,exit;
	private String panel;
	private Game g;
	private dk[] loaded = new dk[10];
	private JButton slots[] = new JButton[10];
	private ArrayList<Card> chosen = new ArrayList<Card>();
	private int deck = 0;
	
	public DeckSelect(Game in){
		g = in;
		panel = "menu";
		exit = new JButton("Exit");
		exit.addActionListener(this);
		deck = 0;
		for (int i = 0; i < 9;i++){
			loaded[i] = load();
			deck+=1;
		}
		for(int i = 0; i<9;i++){
			slots[i] = new JButton(loaded[i].getName());
			add(slots[i]);
			slots[i].addActionListener(this);
		}
		add(exit);
	}
	public dk load(){
		 dk s = null;
	      try {
	         FileInputStream fileIn = new FileInputStream(Board.filePath + "deck" + deck + ".dk");
	         ObjectInputStream in = new ObjectInputStream(fileIn);
	         s = (dk) in.readObject();
	         in.close();
	         fileIn.close();
	      }catch(IOException i) {
	         i.printStackTrace();
	      }catch(ClassNotFoundException c) {
	         System.out.println("dk file missing");
	         c.printStackTrace();
	      }
	      return s;
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		JButton a = (JButton) e.getSource();
		for(int i = 0; i<9;i++){
			if (a == slots[i]){
				if(loaded[i].getCardNum() == 30){
					chosen = new ArrayList<Card>();
					for (int j = 0; j<30;j++){
						chosen.add(DeckBuilder.translate(loaded[i].getCard(j)));
					}
					g.c.remove(g.ds);
					g.game = true;
					g.c.add(g.b);
					g.b.setDeck(chosen);
					g.b.startGame();
					g.c.revalidate();
					g.c.repaint();
				}
			}
		}
		if( a == exit){
			g.c.remove(g.ds);
			g.c.add(g.m);
		}
		
	}
}
