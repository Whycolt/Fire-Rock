
public class Card_Fireball extends Spell{
	
	public Card_Fireball(){
		super("    Fireball",2,1,1,0,"Deal 6 damage.");
	}
	

}
