import java.awt.Color;
import java.awt.Graphics;

public class Hero extends Card{
//Variables
	private int hp,atk,mod,x,y,side;
	private boolean attack;
//Constructor
	public Hero(String name,int side){
		super(name,0,-1,1,side,"");
		attack = true;
		hp = 20;
		atk = 0;
		this.side = side;
	}//end Hero
//Getters and Editors
	public void paintComponent(Graphics g){
		super.paintComponent(g);
		g.drawImage(image, x, y, 100, 100, null);
		g.setColor(Color.red);
		g.fillOval(x+72, y+75, 20, 20);
		g.setColor(Color.white);
		g.drawString(hp+"", x+75, y+90);
		g.setColor(Color.black);
		if (atk>0){
			g.setColor(Color.blue);
			g.fillOval(x, y+75, 20, 20);
			g.setColor(Color.white);
			g.drawString(atk+"", x+5, y+90);
		}
	}//end draw
	//get side of hero
	public int getSide(){
		return side;
	}//end getSide
	//get hp of hero
	public int getHp(){
		return hp;
	}//end getHp
	//get atk of hero
	public int getAtk(){
		return atk;
	}//end getAtk
	//lose or gain health
	public void setHp(Board d, int change){
		if (change < 0)
			hp += (change + mod);
		else
			hp += change;
		if (hp > 20)
			hp = 20;
		checkIsDead(d);
	}//end setHp
	//change atk
	public void setAtk(int change){
		atk += change;
	}//end setAtk
	//change damage mod
	public void setMod(int change){
		mod+=change;
	}//end setMod
	//check if dead
	public void checkIsDead(Board d){
		if (hp <= 0)
			d.turnEnd(this);
	}//end checkIsDead
	public void battle(Board d,Minion card2){
		if (attack){
			this.setHp(d, - card2.getAtk());
			card2.setHp(0, - this.getAtk());
			this.checkIsDead(d);
			card2.checkIsDead(d);
			attack = false;
		}
	}
	public void reset(){
		attack = true;
	}
	//me go face
		public void smorc(Board d, Hero c){
			if (attack){
			c.setHp(d,-(this.getAtk()-c.mod));
			c.checkIsDead(d);
			attack = false;
			}
		}//end smorc
}//end Class Hero
