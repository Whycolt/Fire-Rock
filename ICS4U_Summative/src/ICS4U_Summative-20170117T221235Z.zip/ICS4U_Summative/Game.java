import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.event.*;
import javax.swing.*;

public class Game implements ActionListener{
//Variables
	public Board b;
	public Menu m;
	public Level l;
	public Tutorial t;
	public DeckBuilder d;
	private Timer myTimer;
	public boolean game= true;
	public Container c;
	public DeckSelect ds;
	
//Constructor
	public Game(Container c){
		this.c = c;
		ds = new DeckSelect(this);
		m = new Menu(this);
		d = new DeckBuilder(this);
		t = new Tutorial(this);
		c.add(m);
		b = new Board(0);
		game = false;
		myTimer = new Timer(34,this);
		myTimer.start();
	}
	public void actionPerformed(ActionEvent e) {
	if (e.getSource()==myTimer){
		c.repaint();
		if (game){	
			if(b.over()){
				if((b.getEnd()==2 || b.getEnd()==0) && b.getState()==false){
					b.turnStart(b.player);
				}
				else if(b.getEnd()==1 && b.getState()==false){
					b.turnStart(b.enemy);
					for (int i=0;i<b.enemyMinion.size(); i++){
						b.enemyMinion.get(i).smorc(b,b.player);
					}
					b.turnEnd(b.enemy);
				}
			}
			else{
				if(b.player.getHp() <= 0 && b.enemy.getHp() <= 0){
					System.out.print("tie");
				}
				else if(b.player.getHp() <= 0){
					System.out.println("Defeat");
				}
				else if(b.enemy.getHp() <= 0){
					System.out.println("Victory");
				}
				c.remove(b);
				b = new Board(0);
				c.add(m);
				game = false;
			}
		}
	}
	}
}//end class Game
