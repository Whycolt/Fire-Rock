
public class Card_Broadshield extends Gear{

	public Card_Broadshield(){
		super("Broadshield", 2, 0, 2,0,-1, 2,"Reduce damage by  2                               ");
	}
}
