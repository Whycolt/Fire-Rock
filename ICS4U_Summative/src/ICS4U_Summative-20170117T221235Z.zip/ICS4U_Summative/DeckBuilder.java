import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class DeckBuilder extends JPanel implements ActionListener, Serializable{

	private JButton menu, pre, next,save;
	private JButton slots[] = new JButton[10];
	private JButton cards[] = new JButton[30];
	private int cardindex[] = new int[30];
	private static ArrayList<Card>  col = new ArrayList<Card>();
	boolean edditing;
	private Game g;
	private int deck;
	private String deckName;
	private dk[] loaded = new dk[10];
	private JTextField name;
	
	public DeckBuilder(Game in){
		g = in;
		edditing = false;
		this.setSize(1366, 768);
		loaded[9] = new dk();
		name = new JTextField(10);
		name.addActionListener(this);
		menu = new JButton("Menu");
		menu.addActionListener(this);
		add(menu);
		pre = new JButton("Previous");
		pre.addActionListener(this);
		add(pre);
		next = new JButton("Next");
		next.addActionListener(this);
		add(next);
		save = new JButton("Save");
		save.addActionListener(this);
		deck = 0;
		g.c.repaint();
		for (int i = 0; i < 9;i++){
			loaded[i] = load();
			deck+=1;
		}
		for(int i = 0; i<9;i++){
			slots[i] = new JButton(loaded[i].getName());
			add(slots[i]);
			slots[i].addActionListener(this);
		}
		col.add(new Card_Test_Cow());
		col.add(new Card_FWA());
		col.add(new Card_Broadshield());
		for(int i = 0; i < col.size();i++){
			add(col.get(i));
			col.get(i).addActionListener(this);
		}
		for(int i = 0; i<30;i++){
			cards[i] = new JButton("Empty");
			cards[i].addActionListener(this);
		}
		normal();
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		loaded[deck].setName(name.getText());
		if(e.getSource() instanceof JTextField)
			return;
		JButton b = (JButton) e.getSource();
		if (b instanceof Card){
			System.out.println("Card");
			for(int i = 0; i < col.size();i++){
				if (b == col.get(i)){
					loaded[deck].add(i);
				}
			}
			if (edditing)
			inDeck();
		}
		for (int i = 0; i<30;i++){
			if (b==cards[i]){
				loaded[deck].remove(i);
				inDeck();
			}
		}
		if (b == menu){
			g.c.remove(g.d);
			g.c.add(g.m);
		}
		if (b == next){
			
		}
		if (b == pre){
			
		}
		if (b == save){
			try {
		         FileOutputStream fileOut = new FileOutputStream(Board.filePath + "deck" + deck +".dk");
		         ObjectOutputStream out = new ObjectOutputStream(fileOut);
		         out.writeObject(loaded[deck]);
		         out.close();
		         fileOut.close();
		      }catch(IOException i) {
		         i.printStackTrace();
		      }
				normal();
		}
		for (int i = 0; i<9;i++){
			if (b == slots[i]){
				deck = i;
				editing();
			}
		}
	}
	public dk load(){
		 dk s = null;
	      try {
	         FileInputStream fileIn = new FileInputStream(Board.filePath + "deck" + deck + ".dk");
	         ObjectInputStream in = new ObjectInputStream(fileIn);
	         s = (dk) in.readObject();
	         in.close();
	         fileIn.close();
	      }catch(IOException i) {
	         i.printStackTrace();
	      }catch(ClassNotFoundException c) {
	         System.out.println("dk file missing");
	         c.printStackTrace();
	      }
	      return s;
	}
	
	public void editing(){
		add(save);
		add(name);
		edditing = true;
		name.setText(loaded[deck].getName());
		for(int i = 0; i<9;i++){
			remove(slots[i]);
		}
		inDeck();
		g.c.revalidate();
		g.c.repaint();
		}
	
	public void normal(){
		deck = 9;
		edditing = false;
		outDeck();
		remove(save);
		remove(name);
		for(int i = 0; i<9;i++){
			slots[i].setText((loaded[i].getName()));
			add(slots[i]);
		}
		g.c.revalidate();
		g.c.repaint();
	}
	
	public void inDeck(){
		for(int i = 0; i < 30;i++)
			cards[i].setText("Empty");
		for(int i = 0;i < loaded[deck].getCardNum();i++){
			cards[i].setText(translate(loaded[deck].getCard(i)).getName());
			//cardindex[i] = loaded[deck].getCard(i);
		}
		for(int i = 0; i < 30;i++)
			add(cards[i]);
	}
	public void outDeck(){
		for(int i = 0; i < 30;i++)
			remove(cards[i]);
		g.c.revalidate();
		g.c.repaint();
	}
	
	public static Card translate(int i){
		return (col.get(i).clone());
	}
}
