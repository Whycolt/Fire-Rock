import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;

public class HomeButton extends JButton implements ActionListener{

	private Board b;
	
	public HomeButton(Board on){
		super();
		b = on;
		this.addActionListener(this);
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		System.out.println("exit");
		b.player.setHp(b, -1000);
		b.enemy.setHp(b, -1000);
		b.player.checkIsDead(b);
	}
	
	
}
