
public class Effects {

	protected int type, value;
	public Effects(int type, int value){
		
	}
	
	public void defEff(){
		switch (type){
			case 1: dealDamage(value);
		}
	}
	
	public void dealDamage(int value){
		
	}
}
