import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JPanel;

public class Tutorial extends JPanel implements ActionListener{

	private JButton menu, pre, next, d1,d2,d3,d4,d5,d6,d7,d8,d9;
	private boolean indeck;
	private Game g;
	
	public Tutorial (Game in){
		g = in;
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		JButton b = (JButton) e.getSource();
		if (b == menu){
		}
	}
}
