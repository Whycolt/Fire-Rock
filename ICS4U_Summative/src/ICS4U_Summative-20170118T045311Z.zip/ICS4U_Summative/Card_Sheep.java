
public class Card_Sheep extends Minion{

	public Card_Sheep(){
		super("         Sheep",1,1,1,-1,-1,"",0,0);
	}
}
