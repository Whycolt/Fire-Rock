
public class Card_Dragon_Queen extends Minion{

	public Card_Dragon_Queen(){
		super("    Dragon Queen", 2,6,6,3,5,"Set a Hero's hp to 15",0,0);
	}
}
