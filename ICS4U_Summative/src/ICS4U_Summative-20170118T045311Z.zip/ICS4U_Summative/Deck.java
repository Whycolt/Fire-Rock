import java.io.*;
import java.util.*;

import javax.imageio.ImageIO;

public class Deck {


	ArrayList<Card> deck = new ArrayList<Card>();
	public static final String filePath = new File("").getAbsolutePath() + "/src/";
	private static BufferedReader deckList;
	
	
	public Deck(){
		try {
			deckList = .read(new File(filePath +""));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
}
