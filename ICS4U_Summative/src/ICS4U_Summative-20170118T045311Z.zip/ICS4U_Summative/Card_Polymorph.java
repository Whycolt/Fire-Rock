
public class Card_Polymorph extends Spell{	
	public Card_Polymorph(){
		super("    Polymorph",1,0,2,8,"Polymorph an enemy minion into a 1/1 sheep.",0);
	}
	

}
