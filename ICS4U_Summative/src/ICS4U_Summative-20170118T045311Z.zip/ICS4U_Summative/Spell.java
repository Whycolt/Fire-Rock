import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.JLabel;

public class Spell extends Card{
//Variables
	private int x,y;
	public static BufferedImage defaultS;
//Constructor
	public Spell(String name, int cost, int side,int target,int effect, String text,int value){
		super(name,cost,effect,target,side,text,value);
		this.side = side;
		if (defaultS == null)
			set();
	}//end Spell
//Vital Methods
	//Getting Base Card Image
	public static void set(){
		try {
			defaultS = ImageIO.read(new File(Board.filePath +"Card_Base_S1.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}//end try
	}//end getImg
	//draw Spell
	public void paintComponent(Graphics g){
		g.setFont(Board.smalletter);
		g.drawImage(image, x, y, 95,120, null);
			g.drawImage(defaultS, x, y,95,120,null);
			g.setColor(Color.white);
			g.drawString(cost+"", x+12, y+20);
			g.setColor(Color.black);
			g.drawString(name, x+15, y+70);
			for(int i = 0;i < Math.floor(text.length()/ 18);i++)
				g.drawString(text.substring(i*18, i*18+18), x+16, y+146+14*i);
		}//end draw
//Interactive Methods
	//BattleCry
	public void play(Board b,Card t){//Lets face it, a battlecry is pretty much a spell + body - so spells are basically battlecry
		if (effect != -1){//battlecries will arbitrarily be 1 for now
			b.effect(this,t);
		}//if effects
	}//end checkBattleCry
	public Card clone(){
		Card a = new Spell(name, cost, side,target,effect, text,value);
		return a;
	}
//Getters and Editors
}//end class Minion