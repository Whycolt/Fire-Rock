import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.event.*;
import javax.swing.*;

public class Frame extends JFrame{
//Constructor
	public Frame(){
		super("Working_Title_Here");
		Container c = getContentPane();
		Game g = new Game(c);
		this.setSize(1366, 768);
	}//end Frame
}//end class Main