import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JPanel;

public class Menu extends JPanel implements ActionListener{

	private JButton play,tutorial,deckBuilder,exit;
	private String panel;
	private Game g;
	
	public Menu(Game in){
		g = in;
		panel = "menu";
		play = new JButton("Play");
		play.addActionListener(this);
		add(play);
		tutorial = new JButton("Tutorial");
		tutorial.addActionListener(this);
		add(tutorial);
		deckBuilder = new JButton("Decks");
		deckBuilder.addActionListener(this);
		add(deckBuilder);
		exit = new JButton("Exit");
		exit.addActionListener(this);
		add(exit);
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		JButton a = (JButton) e.getSource();
		if (a == play){
			g.ds.update();
			g.c.remove(g.m);
			g.c.add(g.ds);
			g.c.revalidate();
			g.c.repaint();
		}
		else if (a ==tutorial){
			g.c.remove(g.m);
			g.c.add(g.t);
			g.c.revalidate();
			g.c.repaint();
		}
		else if (a == deckBuilder){
			g.c.remove(g.m);
			g.c.add(g.d);
			g.c.revalidate();
			g.c.repaint();
		}
		else if( a == exit){
			System.exit(0);;
		}
		
	}
}
