
public class Card_Party_Tank extends Minion{
	public Card_Party_Tank(){
		super("    Party Tank", 1, 2,6,-1,-1,"",0,0);
	}

}
