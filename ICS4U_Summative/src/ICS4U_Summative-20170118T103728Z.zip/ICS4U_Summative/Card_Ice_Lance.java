
public class Card_Ice_Lance extends Spell{
	
	public Card_Ice_Lance(){
		super("    Ice Lance",1,0,1,1,"Deal 4 damage.",4);
	}
	

}
