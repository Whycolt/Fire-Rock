
public class Card_River_Croc extends Minion{

	public Card_River_Croc(){
		super("      River Croc",1,2,3,-1,-1,"",0,0);
	}
}
