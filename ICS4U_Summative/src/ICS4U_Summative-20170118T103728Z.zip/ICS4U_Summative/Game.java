import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.*;

public class Game implements ActionListener{
//Variables
	public Board b;
	public Menu m;
	public Level l;
	public Tutorial t;
	public DeckBuilder d;
	private Timer myTimer;
	public boolean game= true;
	public Container c;
	public DeckSelect ds;
	public static final String filePath = new File("").getAbsolutePath() + "/src/";
	public static BufferedImage base = null;
	
//Constructor
	public Game(Container c){
		try {
			base = ImageIO.read(new File(Game.filePath +"Base.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}//end try
		this.c = c;
		ds = new DeckSelect(this);
		m = new Menu(this);
		d = new DeckBuilder(this);
		t = new Tutorial(this);
		c.add(m);
		b = new Board(0);
		game = false;
		myTimer = new Timer(34,this);
		myTimer.start();
	}
	public void actionPerformed(ActionEvent e) {
	if (e.getSource()==myTimer){
		c.repaint();
		if (game){	
			if(b.over()){
				if((b.getEnd()==2 || b.getEnd()==0) && b.getState()==false){
					b.turnStart(b.player);
				}
				else if(b.getEnd()==1 && b.getState()==false){
					b.turnStart(b.enemy);
					for (int i=0;i<b.enemyMinion.size(); i++){
						b.enemyMinion.get(i).smorc(b,b.player);
					}
					b.turnEnd(b.enemy);
				}
			}
			else{
				double i = System.currentTimeMillis();
				Game.pause(i);
				b.revalidate();
				b.repaint();
				c.remove(b);
				b = new Board(0);
				c.add(m);
				game = false;
			}
		}
	}
	}
	public static void pause(double i){
		while (i + 10000 > System.currentTimeMillis()){
		}
		return;
	}
}//end class Game
