
public class Card_Cavalry_Lance extends Gear{
	public Card_Cavalry_Lance(){
		super("Cavalry Lance", 0, 2, 1,0,-1, 1,"Reduce damage taken by 1",0);
	}
}
