public class Card_Tower_Shield extends Gear{

	public Card_Tower_Shield(){
		super("Tower Shield", 2, 0, 6,0,-1, 1,"Reduce damage by  6                               ",0);
	}
}