
public class Card_Devoted_Cleric extends Minion{

	Board b;
	public Card_Devoted_Cleric(){
		super("Devoted Cleric", 1,4,4,1,2, "Give a minion +5 hp", 0,-5);
	}
}
