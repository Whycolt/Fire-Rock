
public class Card_Archmages_Greatstaff extends Gear{
	public Card_Archmages_Greatstaff(){
		super("Achmage's Greatstaff", 2, 8, -2,0,10, 2,"Take 2 extra damage per attack                              ",0);
	}
}
