import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
public class EndButton extends Card{
	
	int x,y;
	public EndButton(){
		super("EndButton", 9999, 9999, 9999, 9999, "Not sure how u got here",0);
	}
	
	public void paintComponent(Graphics g){
		super.paintComponent(g);
		g.drawImage(image, x, y,100,50, null);
	}//end draw
}
