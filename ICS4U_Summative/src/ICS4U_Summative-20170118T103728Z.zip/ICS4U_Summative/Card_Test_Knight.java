
public class Card_Test_Knight extends Minion{

	public Card_Test_Knight() {
		super("        Test Knight",1, 3, 3, 0,0, "Battlecry: Give a Minion +5/+5               ",0,0);
	}
}
