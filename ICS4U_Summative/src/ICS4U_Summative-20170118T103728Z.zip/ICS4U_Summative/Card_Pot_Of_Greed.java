
public class Card_Pot_Of_Greed extends Spell{
	public Card_Pot_Of_Greed(){
		super("    Pot of Greed",0, 0, -1, 7,"Draw 2 cards",2);
	}
}
