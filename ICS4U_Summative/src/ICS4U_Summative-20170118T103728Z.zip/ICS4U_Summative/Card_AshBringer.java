
public class Card_AshBringer extends Gear{
	public Card_AshBringer(){
		super("    AshBringer", 0, 5, 0, 0, -1, 1,"",0);
	}
}
