
public class Card_Sheep extends Minion{

	public Card_Sheep(){
		super("         Sheep",0,1,1,-1,-1,"",1,0);
	}
}
