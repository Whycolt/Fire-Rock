
public class Card_Chained_Ethereal extends Minion{

	public Card_Chained_Ethereal(){
		super("    Chained Ethereal", 2,6,6,1,5,"Deal 5 damage to a hero             ", 0, 5);
	}
}

